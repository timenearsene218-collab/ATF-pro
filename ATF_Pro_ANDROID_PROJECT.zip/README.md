# ATF Pro Android

Projet Android installable pour ATF Pro.

## Générer l'APK sans installer Android Studio
1. Crée un dépôt GitHub.
2. Envoie tout le contenu de ce dossier dans le dépôt.
3. Va dans **Actions**.
4. Lance **Build ATF Pro APK**.
5. Télécharge l'artefact **ATF-Pro-debug**.
6. Tu obtiens `app-debug.apk`, installable sur Android.

## Important
Cette archive est le projet Android et son automatisation de compilation. Le fichier APK lui-même n'a pas pu être compilé dans cet environnement car le SDK Android/outil de build n'est pas installé ici.

L'interface actuelle est embarquée dans l'application. Pour la version commerciale finale, il faudra connecter l'app à l'API cloud ATF Pro et ajouter la signature release.
