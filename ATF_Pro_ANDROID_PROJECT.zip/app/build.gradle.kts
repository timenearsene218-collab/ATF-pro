plugins {
    id("com.android.application")
}

android {
    namespace = "com.atfpro.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.atfpro.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.12.1")
}
